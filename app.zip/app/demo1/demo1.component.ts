import { Component, Input, Output, EventEmitter  } from '@angular/core';

@Component({
  selector: 'app-demo1',
  templateUrl: './demo1.component.html',
  styleUrls: ['./demo1.component.css']
})
export class Demo1Component {
  @Input()
  countn: number = 0;

  @Output()
  change: EventEmitter<number> = new EventEmitter<number>();

  increment() {
    this.countn++;
    this.change.emit(this.countn);
  }

  decrement() {
    this.countn--;
    this.change.emit(this.countn);
  }

  constructor() { }
}
